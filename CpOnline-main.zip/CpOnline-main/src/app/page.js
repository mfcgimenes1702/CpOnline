import NavBar from "@/components/NavBar";
import Link from "next/link";

export default function Home() {
  return (
    <>
      <NavBar />

      <main className="bg-slate-300 m-20 p-8">
        <h2>Home</h2>
      </main>
    </>

  )
}
