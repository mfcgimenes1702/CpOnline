import NavBar from "@/components/NavBar";

export default function MenuAluno() {
  return (

<>
  <NavBar/>

    <main className="bg-slate-300 m-20 p-8">
      <h2>Menu Aluno</h2>
    </main>
  </>
    
  )
}
