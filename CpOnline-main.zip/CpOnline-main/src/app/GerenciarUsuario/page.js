
import NavBar from "@/components/NavBar";

export default function GerenciarUsuario() {
  return (

<>
  <NavBar/>

    <main className="bg-slate-300 m-20 p-8">
      <h2>Gerenciar Usuário</h2>
    </main>
  </>
    
  )
}
