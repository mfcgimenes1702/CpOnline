import NavBar from "@/components/NavBar";

export default function MenuProfessor() {
  return (

<>
  <NavBar/>

    <main className="bg-slate-300 m-20 p-8">
      <h2>Menu Professor</h2>
    </main>
  </>
    
  )
}
