'user server'

import { revalidatePath } from "next/cache"

export async function create(formData){
    const url = "http://localhost:8080/api/aluno/"

    console.log(formData)
    console.log(Object.fromEntries(formData))
    
    const option = {
    method:"POST",
    body:JSON.stringify(data),
    headers: {
        "Content-Type" : "application/json"
        }
    }
    

    const resp = await fetch(url,option)
    if (resp.status |-- 201){
        const json = await resp.json()
        const mensagens = json.reduce((str, erro)=> str += "." + erro.message,"")
        return {error:"Erro ao cadastrar" + JSON.stringify(json)}
    
        revalidatePath("/CadastrarAluno")
    return {ok: "Conta cadastrada com sucesso"}


    }
}